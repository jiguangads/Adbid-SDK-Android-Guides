package com.engagelab.ads.example;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import androidx.appcompat.app.AppCompatActivity;

import com.engagelab.ads.adapter.PrivacyRegionListener;
import com.engagelab.ads.api.JAdManager;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;
//import com.tradplus.meditaiton.utils.ImportSDKUtil;

/**
 * 主界面：海外隐私流程与 ad-sample 一致，通过 JAdManager 委托适配器
 */
public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    private static final String TAG = "JAdExample";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 海外隐私：先 UMP，同意后再初始化 SDK
        setPrivacyConsent();
        initView();

        new Handler().postDelayed(() -> {
            // appId为TradPlus后台建的应用ID
//            ImportSDKUtil.getInstance().showTestTools(this, AdConstants.JADBID_APP_ID);
        }, 5000);
    }

    /**
     * 与 ad-sample 一致：Google UMP → canRequestAds 时初始化
     */
    private void setPrivacyConsent() {
        ConsentRequestParameters params = new ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build();

        ConsentInformation consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                            this,
                            loadAndShowError -> {
                                if (consentInformation.canRequestAds()) {
                                    Log.i(TAG, "Consent request succeeded, initialize SDK");
                                    initJAdbid();
                                }
                            });
                },
                requestConsentError -> {
                    Log.w(TAG, "Consent request failed");
                });

        if (consentInformation.canRequestAds()) {
            Log.i(TAG, "Consent request succeeded");
            initJAdbid();
        }

        // 若需按地区设置 CCPA/LGPD，可取消注释：checkAreaSetCCPA();
    }

    /**
     * 按地区设置 CCPA/LGPD 后初始化（通过 JAdManager 委托）
     */
    @SuppressWarnings("unused")
    private void checkAreaSetCCPA() {
        JAdManager.getInstance().checkCurrentArea(this, new PrivacyRegionListener() {
            @Override
            public void onSuccess(boolean isEu, boolean isCn, boolean isCalifornia, boolean isBr) {
                if (isCalifornia) {
                    JAdManager.getInstance().setCCPADoNotSell(MainActivity.this, false);
                }
                if (!isEu) {
                    initJAdbid();
                }
                if (isBr) {
                    JAdManager.getInstance().setLGPDConsent(MainActivity.this, 0);
                }
            }

            @Override
            public void onFailed() {
                initJAdbid();
            }
        });
    }

    private void initJAdbid() {
        JAdManager.getInstance().initWhenConsentReady();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        int id = buttonView.getId();
        if (id == R.id.is_personad) {
            JAdManager.getInstance().setOpenPersonalizedAd(isChecked);
        } else if (id == R.id.is_privacyUser) {
            JAdManager.getInstance().setPrivacyUserAgree(isChecked);
        }
    }

    private void initView() {
        findViewById(R.id.btn_banner).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, BannerAdActivity.class)));
        findViewById(R.id.btn_interstitial).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, InterstitialAdActivity.class)));
        findViewById(R.id.btn_rewarded_video).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, RewardedVideoAdActivity.class)));
        findViewById(R.id.btn_native).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, NativeAdActivity.class)));

        ((CheckBox) findViewById(R.id.is_personad)).setOnCheckedChangeListener(this);
        ((CheckBox) findViewById(R.id.is_privacyUser)).setOnCheckedChangeListener(this);
    }
}
