package com.engagelab.ads.example;

import android.app.Application;
import android.content.Context;

import androidx.multidex.MultiDex;

import com.engagelab.ads.api.JAdManager;
import com.engagelab.ads.config.JAdConfig;
import com.engagelab.ads.config.JAdapterType;

/**
 * 示例Application
 */
public class ExampleApplication extends Application {

    @Override
    protected void attachBaseContext(Context base) {
        MultiDex.install(this);
        super.attachBaseContext(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        JAdConfig config = new JAdConfig.Builder(AdConstants.JADBID_APP_ID)
                .setDebugMode(true)
                .setTestMode(true)
                .setAdapterType(JAdapterType.TYPE_DEFAULT)
                .build();

        // 仅准备初始化参数，等隐私同意后再在 MainActivity 中调用 initWhenConsentReady()
        JAdManager.getInstance().prepareInit(this, config);
    }
}

