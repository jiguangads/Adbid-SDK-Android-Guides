package com.engagelab.ads.example;

/**
 * 示例工程中广告应用 ID 与广告位 ID：由本模块 defaultConfig 的 buildConfigField 注入 BuildConfig。
 */
public interface AdConstants {

    String JADBID_APP_ID = BuildConfig.JADBID_APP_ID;

    String BANNER_AD_UNIT_ID = BuildConfig.BANNER_AD_UNIT_ID;

    String INTERSTITIAL_AD_UNIT_ID = BuildConfig.INTERSTITIAL_AD_UNIT_ID;

    String REWARDED_VIDEO_AD_UNIT_ID = BuildConfig.REWARDED_VIDEO_AD_UNIT_ID;

    String NATIVE_AD_UNIT_ID = BuildConfig.NATIVE_AD_UNIT_ID;
}
