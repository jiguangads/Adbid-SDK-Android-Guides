# JAdbid SDK 对外集成演示工程

本目录为 **随发版包 `dist/demo` 提供的源码 Demo**，与仓库根目录下的 **`ad-example`（内部多 profile 测试工程）** 源码隔离，互不影响。

## 工程结构

| 模块 | 说明 |
|------|------|
| **standard** | 标准包：`libs/` 下主 AAR + 渠道插件 AAR + Maven 声明各广告源（与集成文档「标准包」一致） |

Demo 的 **`applicationId` 为 `com.engagelab.ads.example`**，用于验证标准包接入流程。

## 使用方式

**在 jadbid-sdk 仓库内**（已包含本目录时）：

```bash
./gradlew :example:standard:assembleDebug
```

**单独打开本目录**（例如解压 `dist/demo` 下的 ZIP 后）：

```bash
cd jadbid-android-example-<version>   # 解压后的顶层目录名以发版包为准
./gradlew :standard:assembleDebug
```

发版脚本会在 `standard/libs/` 写入对应版本的主 AAR。若本地克隆仓库后未执行 `build-all.sh`，请将 `jadbid-android-*.aar` 自行放入 `standard/libs/`。

## 配置说明

广告应用 ID 与广告位 ID 在各模块 `build.gradle` 的 `defaultConfig.buildConfigField` 中配置（占位值可替换为你的正式 ID）。代码通过 `AdConstants` 读取 `BuildConfig`。

## 单独打开 `example/` 目录时

解压发版 ZIP 后若**仅**用本目录作为工程根目录构建，请配置 Android SDK 路径（与常规 Android 工程相同）：

- 在 `example/` 下创建 `local.properties`，写入 `sdk.dir=/path/to/Android/sdk`，或  
- 设置环境变量 `ANDROID_HOME`。
