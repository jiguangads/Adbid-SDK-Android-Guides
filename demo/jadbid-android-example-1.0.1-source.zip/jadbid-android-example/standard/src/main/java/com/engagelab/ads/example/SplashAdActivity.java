package com.engagelab.ads.example;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.engagelab.ads.api.JSplashAd;
import com.engagelab.ads.bean.JAdInfo;
import com.engagelab.ads.error.JAdError;
import com.engagelab.ads.listener.JSplashAdListener;

/** 开屏广告预加载和显式容器展示示例。 */
public class SplashAdActivity extends AppCompatActivity {
    private static final long HOST_LOAD_TIMEOUT_MS = 5000L;

    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private JSplashAd mSplashAd;
    private FrameLayout mAdContainer;
    private TextView mStatus;
    private Runnable mLoadTimeout;
    private int mLoadGeneration;
    private boolean mLoadPending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_ad);
        mAdContainer = findViewById(R.id.ad_container);
        mStatus = findViewById(R.id.tv_status);
        findViewById(R.id.btn_load).setOnClickListener(view -> loadAd());
        findViewById(R.id.btn_show).setOnClickListener(view -> showAd());
        findViewById(R.id.btn_abandon).setOnClickListener(view ->
                abandonCurrentLoad("宿主已放弃本次开屏广告"));
    }

    private void loadAd() {
        if (!ensureConfigured()) return;
        destroyAd();
        mAdContainer.removeAllViews();
        int generation = ++mLoadGeneration;
        mLoadPending = true;
        updateStatus("正在预加载；5 秒未完成时由宿主放弃，不会自动展示");
        try {
            mSplashAd = new JSplashAd(AdConstants.SPLASH_AD_UNIT_ID);
            mSplashAd.loadAd(this, new JSplashAdListener() {
                @Override public void onAdLoaded(JAdInfo adInfo) {
                    if (!isCurrent(generation)) return;
                    mLoadPending = false;
                    cancelLoadTimeout();
                    updateStatus("加载完成，可以手动展示");
                }
                @Override public void onAdLoadFailed(JAdError error) {
                    if (!isCurrent(generation)) return;
                    mLoadPending = false;
                    cancelLoadTimeout();
                    updateStatus(errorText("加载失败", error));
                }
                @Override public void onAdShown(JAdInfo adInfo) {
                    if (!isCurrent(generation)) return;
                    updateStatus("广告已展示");
                }
                @Override public void onAdClicked(JAdInfo adInfo) {
                    if (!isCurrent(generation)) return;
                    updateStatus("广告已点击");
                }
                @Override public void onAdClosed(JAdInfo adInfo) {
                    if (!isCurrent(generation)) return;
                    updateStatus("广告已关闭");
                }
                @Override public void onAdShowFailed(JAdError error) {
                    if (!isCurrent(generation)) return;
                    updateStatus(errorText("展示失败", error));
                }
            });
            if (mLoadPending && isCurrent(generation)) scheduleLoadTimeout(generation);
        } catch (IllegalArgumentException | IllegalStateException exception) {
            mLoadPending = false;
            cancelLoadTimeout();
            updateStatus("无法创建广告：请确认外部配置和 SDK 初始化状态");
        }
    }

    private void showAd() {
        if (mSplashAd == null || !mSplashAd.isReady()) {
            updateStatus("广告尚未就绪");
            return;
        }
        mSplashAd.showAd(mAdContainer);
    }

    private boolean ensureConfigured() {
        if (!AdConstants.isConfigured(AdConstants.JADBID_APP_ID)) {
            showMissing("JADBID_APP_ID");
            return false;
        }
        if (!AdConstants.isConfigured(AdConstants.GOOGLE_ADMOB_APP_ID)) {
            showMissing("GOOGLE_ADMOB_APP_ID");
            return false;
        }
        if (!AdConstants.isConfigured(AdConstants.SPLASH_AD_UNIT_ID)) {
            showMissing("SPLASH_AD_UNIT_ID");
            return false;
        }
        return true;
    }

    private void showMissing(String propertyName) {
        String message = AdConstants.missingConfigurationMessage(propertyName);
        updateStatus(message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void updateStatus(String message) {
        mStatus.setText(message);
    }

    private static String errorText(String action, JAdError error) {
        return error == null ? action : action + "（错误码 " + error.getCode() + "）";
    }

    private void scheduleLoadTimeout(int generation) {
        cancelLoadTimeout();
        mLoadTimeout = () -> {
            if (!isCurrent(generation)) return;
            abandonCurrentLoad("宿主等待超时，已放弃本次开屏广告");
        };
        mMainHandler.postDelayed(mLoadTimeout, HOST_LOAD_TIMEOUT_MS);
    }

    private void cancelLoadTimeout() {
        if (mLoadTimeout != null) {
            mMainHandler.removeCallbacks(mLoadTimeout);
            mLoadTimeout = null;
        }
    }

    private boolean isCurrent(int generation) {
        return generation == mLoadGeneration && mSplashAd != null;
    }

    private void abandonCurrentLoad(String status) {
        mLoadGeneration++;
        mLoadPending = false;
        cancelLoadTimeout();
        destroyAd();
        mAdContainer.removeAllViews();
        updateStatus(status);
    }

    private void destroyAd() {
        if (mSplashAd != null) {
            mSplashAd.destroy();
            mSplashAd = null;
        }
    }

    @Override
    protected void onDestroy() {
        mLoadGeneration++;
        mLoadPending = false;
        cancelLoadTimeout();
        destroyAd();
        super.onDestroy();
    }
}
