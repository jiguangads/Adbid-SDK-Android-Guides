package com.engagelab.ads.example;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.engagelab.ads.api.JRewardedVideoAd;
import com.engagelab.ads.bean.JAdInfo;
import com.engagelab.ads.error.JAdError;
import com.engagelab.ads.listener.JRewardedVideoAdListener;

/**
 * 激励视频广告示例
 */
public class RewardedVideoAdActivity extends AppCompatActivity {
    private static final String TAG = "RewardedVideoAdActivity";

    private JRewardedVideoAd mRewardedVideoAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rewarded_video_ad);

        // 加载按钮
        findViewById(R.id.btn_load).setOnClickListener(v -> loadRewardedVideoAd());

        // 展示按钮
        findViewById(R.id.btn_show).setOnClickListener(v -> showRewardedVideoAd());
    }

    private void loadRewardedVideoAd() {
        Log.d(TAG, "Start loading rewarded video ad");
        
        // 创建激励视频广告实例
        mRewardedVideoAd = new JRewardedVideoAd(AdConstants.REWARDED_VIDEO_AD_UNIT_ID);

        // 加载广告
        mRewardedVideoAd.loadAd(this, new JRewardedVideoAdListener() {
            @Override
            public void onAdLoaded(JAdInfo adInfo) {
                Log.d(TAG, "Rewarded video ad loaded successfully");
                Toast.makeText(RewardedVideoAdActivity.this, "Ad loaded successfully", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdLoadFailed(JAdError error) {
                Log.e(TAG, "Rewarded video ad load failed: " + error.toString());
                Toast.makeText(RewardedVideoAdActivity.this, "Ad load failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdShown(JAdInfo adInfo) {
                Log.d(TAG, "Rewarded video ad shown");
            }

            @Override
            public void onAdClicked(JAdInfo adInfo) {
                Log.d(TAG, "Rewarded video ad clicked");
            }

            @Override
            public void onAdClosed(JAdInfo adInfo) {
                Log.d(TAG, "Rewarded video ad closed");
            }

            @Override
            public void onAdShowFailed(JAdError error) {
                Log.e(TAG, "Rewarded video ad show failed: " + error.toString());
            }

            @Override
            public void onAdRewarded(JAdInfo adInfo) {
                String name = adInfo != null ? adInfo.rewardName : "Reward";
                int amount = adInfo != null ? adInfo.rewardNumber : 1;
                Log.d(TAG, "Reward granted: " + name + " x " + amount);
                Toast.makeText(RewardedVideoAdActivity.this,
                    "Reward: " + name + " x " + amount,
                    Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onVideoPlayStart(JAdInfo adInfo) {
                Log.d(TAG, "Video play start");
            }

            @Override
            public void onVideoPlayEnd(JAdInfo adInfo) {
                Log.d(TAG, "Video play end");
            }
        });
    }

    private void showRewardedVideoAd() {
        if (mRewardedVideoAd != null && mRewardedVideoAd.isReady()) {
            mRewardedVideoAd.showAd(this);
        } else {
            Toast.makeText(this, "Ad not ready", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mRewardedVideoAd != null) {
            mRewardedVideoAd.destroy();
        }
    }
}

