package com.engagelab.ads.example;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.engagelab.ads.api.JNativeAd;
import com.engagelab.ads.bean.JAdInfo;
import com.engagelab.ads.error.JAdError;
import com.engagelab.ads.listener.JNativeAdListener;

/**
 * 原生广告示例
 *
 * <p>展示如何通过 JAdbid SDK 加载并展示原生广告（模板渲染方式）：</p>
 * <ol>
 *   <li>点击「加载」发起广告请求</li>
 *   <li>收到 {@code onAdLoaded} 回调后「展示」按钮变为可用</li>
 *   <li>点击「展示」将广告渲染到页面容器中</li>
 * </ol>
 */
public class NativeAdActivity extends AppCompatActivity {

    private static final String TAG = "NativeAdActivity";

    private JNativeAd mNativeAd;
    private FrameLayout mAdContainer;
    private Button mBtnShow;
    private TextView mTvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_native_ad);

        mAdContainer = findViewById(R.id.ad_container);
        mBtnShow    = findViewById(R.id.btn_show);
        mTvStatus   = findViewById(R.id.tv_status);

        mBtnShow.setEnabled(false);

        mNativeAd = new JNativeAd(AdConstants.NATIVE_AD_UNIT_ID);

        findViewById(R.id.btn_load).setOnClickListener(v -> loadAd());
        mBtnShow.setOnClickListener(v -> showAd());
    }

    /**
     * 加载原生广告
     */
    private void loadAd() {
        updateStatus("Loading...");
        mBtnShow.setEnabled(false);
        mAdContainer.removeAllViews();
        Log.d(TAG, "loadAd: start loading native ad, adUnitId=" + AdConstants.NATIVE_AD_UNIT_ID);

        mNativeAd.loadAd(this, new JNativeAdListener() {
            @Override
            public void onAdLoaded(JAdInfo adInfo) {
                Log.d(TAG, "onAdLoaded: loaded successfully, adSource=" + (adInfo != null ? adInfo.adSourceName : "unknown"));
                updateStatus("Loaded. Tap Show to render ad");
                mBtnShow.setEnabled(true);
                Toast.makeText(NativeAdActivity.this, "Native ad loaded successfully", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdLoadFailed(JAdError error) {
                Log.e(TAG, "onAdLoadFailed: code=" + error.getCode() + ", msg=" + error.getMessage());
                updateStatus("Load failed: " + error.getMessage());
                mBtnShow.setEnabled(false);
                Toast.makeText(NativeAdActivity.this, "Load failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdShown(JAdInfo adInfo) {
                Log.d(TAG, "onAdShown: ad shown");
                updateStatus("Ad showing");
            }

            @Override
            public void onAdClicked(JAdInfo adInfo) {
                Log.d(TAG, "onAdClicked: ad clicked");
                Toast.makeText(NativeAdActivity.this, "Ad clicked", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdClosed(JAdInfo adInfo) {
                Log.d(TAG, "onAdClosed: ad closed");
                updateStatus("Ad closed");
                mBtnShow.setEnabled(false);
            }
        });
    }

    /**
     * 展示原生广告（模板渲染方式）
     *
     * <p>使用 {@code tp_native_ad_list_item} 布局作为广告模板，
     * TradPlus SDK 会自动将广告素材（标题、图片、CTA 按钮等）填充到对应 View 中。</p>
     */
    private void showAd() {
        if (!mNativeAd.isReady()) {
            Toast.makeText(this, "Ad not ready, load first", Toast.LENGTH_SHORT).show();
            return;
        }
        Log.d(TAG, "showAd: render native ad to container");
        mNativeAd.showAd(mAdContainer, R.layout.tp_native_ad_list_item);
    }

    private void updateStatus(String msg) {
        if (mTvStatus != null) {
            mTvStatus.setText(msg);
        }
    }

    @Override
    protected void onDestroy() {
        if (mNativeAd != null) {
            mNativeAd.destroy();
        }
        super.onDestroy();
    }
}
