package com.engagelab.ads.example;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.engagelab.ads.adapter.PrivacyRegionListener;
import com.engagelab.ads.api.JAdManager;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;
//import com.tradplus.meditaiton.utils.ImportSDKUtil;

/**
 * 主界面：海外隐私流程与 ad-sample 一致，通过 JAdManager 委托适配器
 */
public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    private static final String TAG = "JAdExample";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 海外隐私：先 UMP，同意后再初始化 SDK
        setPrivacyConsent();
        initView();
        if (!AdConstants.isConfigured(AdConstants.JADBID_APP_ID)) {
            Toast.makeText(this,
                    AdConstants.missingConfigurationMessage("JADBID_APP_ID"),
                    Toast.LENGTH_LONG).show();
        } else if (!AdConstants.isConfigured(AdConstants.GOOGLE_ADMOB_APP_ID)) {
            Toast.makeText(this,
                    AdConstants.missingConfigurationMessage("GOOGLE_ADMOB_APP_ID"),
                    Toast.LENGTH_LONG).show();
        }

        new Handler().postDelayed(() -> {
            // appId为TradPlus后台建的应用ID
//            ImportSDKUtil.getInstance().showTestTools(this, AdConstants.JADBID_APP_ID);
        }, 5000);
    }

    /**
     * 与 ad-sample 一致：Google UMP → canRequestAds 时初始化
     */
    private void setPrivacyConsent() {
        ConsentRequestParameters params = new ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build();

        ConsentInformation consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                            this,
                            loadAndShowError -> {
                                if (consentInformation.canRequestAds()) {
                                    Log.i(TAG, "Consent request succeeded, initialize SDK");
                                    initJAdbid();
                                }
                            });
                },
                requestConsentError -> {
                    Log.w(TAG, "Consent request failed");
                });

        if (consentInformation.canRequestAds()) {
            Log.i(TAG, "Consent request succeeded");
            initJAdbid();
        }

        // 若需按地区设置 CCPA/LGPD，可取消注释：checkAreaSetCCPA();
    }

    /**
     * 按地区设置 CCPA/LGPD 后初始化（通过 JAdManager 委托）
     */
    @SuppressWarnings("unused")
    private void checkAreaSetCCPA() {
        JAdManager.getInstance().checkCurrentArea(this, new PrivacyRegionListener() {
            @Override
            public void onSuccess(boolean isEu, boolean isCn, boolean isCalifornia, boolean isBr) {
                if (isCalifornia) {
                    JAdManager.getInstance().setCCPADoNotSell(MainActivity.this, false);
                }
                if (!isEu) {
                    initJAdbid();
                }
                if (isBr) {
                    JAdManager.getInstance().setLGPDConsent(MainActivity.this, 0);
                }
            }

            @Override
            public void onFailed() {
                initJAdbid();
            }
        });
    }

    private void initJAdbid() {
        if (!AdConstants.isConfigured(AdConstants.JADBID_APP_ID)
                || !AdConstants.isConfigured(AdConstants.GOOGLE_ADMOB_APP_ID)) {
            return;
        }
        JAdManager.getInstance().initWhenConsentReady();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        int id = buttonView.getId();
        if (id == R.id.is_personad) {
            JAdManager.getInstance().setOpenPersonalizedAd(isChecked);
        } else if (id == R.id.is_privacyUser) {
            JAdManager.getInstance().setPrivacyUserAgree(isChecked);
        }
    }

    private void initView() {
        findViewById(R.id.btn_banner).setOnClickListener(v ->
                openAdExample(BannerAdActivity.class,
                        "BANNER_AD_UNIT_ID", AdConstants.BANNER_AD_UNIT_ID));
        findViewById(R.id.btn_interstitial).setOnClickListener(v ->
                openAdExample(InterstitialAdActivity.class,
                        "INTERSTITIAL_AD_UNIT_ID", AdConstants.INTERSTITIAL_AD_UNIT_ID));
        findViewById(R.id.btn_rewarded_video).setOnClickListener(v ->
                openAdExample(RewardedVideoAdActivity.class,
                        "REWARDED_VIDEO_AD_UNIT_ID", AdConstants.REWARDED_VIDEO_AD_UNIT_ID));
        findViewById(R.id.btn_native).setOnClickListener(v ->
                openAdExample(NativeAdActivity.class,
                        "NATIVE_AD_UNIT_ID", AdConstants.NATIVE_AD_UNIT_ID));
        findViewById(R.id.btn_splash).setOnClickListener(v ->
                openAdExample(SplashAdActivity.class,
                        "SPLASH_AD_UNIT_ID", AdConstants.SPLASH_AD_UNIT_ID));
        ((CheckBox) findViewById(R.id.is_personad)).setOnCheckedChangeListener(this);
        ((CheckBox) findViewById(R.id.is_privacyUser)).setOnCheckedChangeListener(this);
    }

    private void openAdExample(
            Class<?> activityClass, String propertyName, String adUnitId) {
        if (!AdConstants.isConfigured(AdConstants.JADBID_APP_ID)) {
            showMissingConfiguration("JADBID_APP_ID");
            return;
        }
        if (!AdConstants.isConfigured(AdConstants.GOOGLE_ADMOB_APP_ID)) {
            showMissingConfiguration("GOOGLE_ADMOB_APP_ID");
            return;
        }
        if (!AdConstants.isConfigured(adUnitId)) {
            showMissingConfiguration(propertyName);
            return;
        }
        startActivity(new Intent(this, activityClass));
    }

    private void showMissingConfiguration(String propertyName) {
        Toast.makeText(this,
                AdConstants.missingConfigurationMessage(propertyName),
                Toast.LENGTH_LONG).show();
    }
}
