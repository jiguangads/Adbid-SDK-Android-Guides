package com.engagelab.ads.example;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.engagelab.ads.api.JAdManager;
import com.engagelab.ads.api.JBannerAd;
import com.engagelab.ads.bean.JAdInfo;
import com.engagelab.ads.error.JAdError;
import com.engagelab.ads.listener.JBannerAdListener;

/**
 * 横幅广告示例
 */
public class BannerAdActivity extends AppCompatActivity {
    private static final String TAG = "BannerAdActivity";

    private JBannerAd mBannerAd;
    private FrameLayout mBannerContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banner_ad);

        mBannerContainer = findViewById(R.id.banner_container);

        // 加载按钮
        findViewById(R.id.btn_load).setOnClickListener(v -> loadBannerAd());
    }

    private void loadBannerAd() {
        Log.d(TAG, "Start loading banner ad");
        
        try {
            // 创建横幅广告实例（内部会自动等待初始化完成）
            mBannerAd = new JBannerAd(AdConstants.BANNER_AD_UNIT_ID);
            
            // 加载广告
            mBannerAd.loadAd(this, new JBannerAdListener() {
            @Override
            public void onAdLoaded(JAdInfo adInfo) {
                Log.d(TAG, "Banner ad loaded successfully");
                Toast.makeText(BannerAdActivity.this, "Ad loaded successfully", Toast.LENGTH_SHORT).show();
                
                // 获取Banner View并添加到容器中
                View bannerView = mBannerAd.getBannerView();
                if (bannerView != null) {
                    mBannerContainer.removeAllViews();
                    mBannerContainer.addView(bannerView);
                }
            }

            @Override
            public void onAdLoadFailed(JAdError error) {
                Log.e(TAG, "Banner ad load failed: " + error.toString());
                Toast.makeText(BannerAdActivity.this, "Ad load failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdShown(JAdInfo adInfo) {
                Toast.makeText(BannerAdActivity.this, "Ad shown", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Ad shown: " + adInfo.toString());
            }

            @Override
            public void onAdClicked(JAdInfo adInfo) {
                Log.d(TAG, "Banner ad clicked");
            }

            @Override
            public void onAdClosed(JAdInfo adInfo) {
                Log.d(TAG, "Banner ad closed");
            }
            });
        } catch (IllegalStateException e) {
            Log.e(TAG, "Failed to create ad: " + e.getMessage());
            Toast.makeText(this, "SDK init failed, check log: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mBannerAd != null) {
            mBannerAd.destroy();
        }
    }
}

