package com.engagelab.ads.example;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.engagelab.ads.api.JInterstitialAd;
import com.engagelab.ads.bean.JAdInfo;
import com.engagelab.ads.error.JAdError;
import com.engagelab.ads.listener.JInterstitialAdListener;

/**
 * 插屏广告示例
 */
public class InterstitialAdActivity extends AppCompatActivity {
    private static final String TAG = "InterstitialAdActivity";

    private JInterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interstitial_ad);

        // 加载按钮
        findViewById(R.id.btn_load).setOnClickListener(v -> loadInterstitialAd());

        // 展示按钮
        findViewById(R.id.btn_show).setOnClickListener(v -> showInterstitialAd());
    }

    private void loadInterstitialAd() {
        Log.d(TAG, "Start loading interstitial ad");
        
        // 创建插屏广告实例
        mInterstitialAd = new JInterstitialAd(AdConstants.INTERSTITIAL_AD_UNIT_ID);

        // 加载广告
        mInterstitialAd.loadAd(this, new JInterstitialAdListener() {
            @Override
            public void onAdLoaded(JAdInfo adInfo) {
                Log.d(TAG, "Interstitial ad loaded successfully");
                Toast.makeText(InterstitialAdActivity.this, "Ad loaded successfully", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdLoadFailed(JAdError error) {
                Log.e(TAG, "Interstitial ad load failed: " + error.toString());
                Toast.makeText(InterstitialAdActivity.this, "Ad load failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdShown(JAdInfo adInfo) {
                Log.d(TAG, "Interstitial ad shown");
            }

            @Override
            public void onAdClicked(JAdInfo adInfo) {
                Log.d(TAG, "Interstitial ad clicked");
            }

            @Override
            public void onAdClosed(JAdInfo adInfo) {
                Log.d(TAG, "Interstitial ad closed");
            }

            @Override
            public void onAdShowFailed(JAdError error) {
                Log.e(TAG, "Interstitial ad show failed: " + error.toString());
            }

            @Override
            public void onVideoPlayStart(JAdInfo adInfo) {
                Log.d(TAG, "Interstitial video play start");
            }

            @Override
            public void onVideoPlayEnd(JAdInfo adInfo) {
                Log.d(TAG, "Interstitial video play end");
            }
        });
    }

    private void showInterstitialAd() {
        if (mInterstitialAd != null && mInterstitialAd.isReady()) {
            mInterstitialAd.showAd(this);
        } else {
            Toast.makeText(this, "Ad not ready", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mInterstitialAd != null) {
            mInterstitialAd.destroy();
        }
    }
}

