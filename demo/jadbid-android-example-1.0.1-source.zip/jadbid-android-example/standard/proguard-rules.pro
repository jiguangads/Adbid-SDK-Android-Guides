# Add project specific ProGuard rules here.

# JAdbid SDK
-keep class com.engagelab.ads.** { *; }
-keep interface com.engagelab.ads.** { *; }

# TradPlus SDK
-keep class com.tradplus.** { *; }
-keep class com.tp.adx.** { *; }
-keep class com.tradplus.ads.** { *; }

# 保留所有 R 类
-keep class **.R
-keep class **.R$* { *; }
