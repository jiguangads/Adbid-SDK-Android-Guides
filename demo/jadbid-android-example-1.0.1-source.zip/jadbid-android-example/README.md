# JAdbid SDK 对外集成演示工程

本目录为 **随发版包 `dist/demo` 提供的源码 Demo**，与仓库根目录下的 **`ad-example`（内部多 profile 测试工程）** 源码隔离，互不影响。

## 工程结构

| 模块 | 说明 |
|------|------|
| **standard** | 标准包：`libs/` 下主 AAR + 渠道插件 AAR + Maven 声明各广告源（与集成文档「标准包」一致） |

Demo 的 **`applicationId` 为 `com.engagelab.ads.example`**，用于验证标准包接入流程。

## 使用方式

**在 jadbid-sdk 仓库内**（已包含本目录时）：

```bash
./gradlew :example:standard:assembleDebug
```

**单独打开本目录**（例如解压 `dist/demo` 下的 ZIP 后）：

```bash
cd jadbid-android-example-<version>   # 解压后的顶层目录名以发版包为准
./gradlew :standard:assembleDebug
```

发版脚本会在 `standard/libs/` 写入对应版本的主 AAR。若本地克隆仓库后未执行 `build-all.sh`，请将 `jadbid-android-*.aar` 自行放入 `standard/libs/`。

## 配置说明

仓库不保存 App ID、广告位 ID、媒体 URL 或其它测试标识。请通过同名 Gradle property 或环境变量注入，代码再由 `AdConstants` 从 `BuildConfig` 读取：

```properties
JADBID_APP_ID=<由测试环境提供>
BANNER_AD_UNIT_ID=<由测试环境提供>
INTERSTITIAL_AD_UNIT_ID=<由测试环境提供>
REWARDED_VIDEO_AD_UNIT_ID=<由测试环境提供>
NATIVE_AD_UNIT_ID=<由测试环境提供>
SPLASH_AD_UNIT_ID=<由测试环境提供>
GOOGLE_ADMOB_APP_ID=<由测试环境提供>
```

可将这些属性放入用户级 `~/.gradle/gradle.properties`，也可设置同名环境变量。不要把真实值写入仓库、命令输出或问题记录。缺少 JABID 或 AdMob 应用 ID 时示例不会初始化 SDK；缺少对应广告位时，该页面会明确提示并停止请求。

标准示例覆盖开屏预加载与显式展示，以及横幅、插屏、激励视频和原生广告的基础接入。示例构建通过只证明公开 API 和资源接入正确；只有安全注入外部 ID 并在 API 23、Android 14+ 真机完成主链路后，才可声称真机验证通过。

## 单独打开 `example/` 目录时

解压发版 ZIP 后若**仅**用本目录作为工程根目录构建，请配置 Android SDK 路径（与常规 Android 工程相同）：

- 在 `example/` 下创建 `local.properties`，写入 `sdk.dir=/path/to/Android/sdk`，或  
- 设置环境变量 `ANDROID_HOME`。
